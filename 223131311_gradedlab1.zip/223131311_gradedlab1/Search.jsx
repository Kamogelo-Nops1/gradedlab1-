import React from 'react';

function SearchBar(props) {
  const {
    searchText,
    onSearchChange,
    selectedCategory,
    onCategoryChange,
    inStockOnly,
    onInStockChange
  } = props;

  return (
    <div style={{ marginBottom: '20px' }}>
      <input
        type="text"
        placeholder="Search..."
        value={searchText}
        onChange={(e) => onSearchChange(e.target.value)}
      />

      <select value={selectedCategory} onChange={(e) => onCategoryChange(e.target.value)}>
        <option value="All">All</option>
        <option value="Clothing">Clothing</option>
        <option value="Shoes">Shoes</option>
        <option value="Accessories">Accessories</option>
        <option value="Furniture">Furniture</option>
      </select>

      <label style={{ marginLeft: '10px' }}>
        <input
          type="checkbox"
          checked={inStockOnly}
          onChange={(e) => onInStockChange(e.target.checked)}
        />
        In Stock Only
      </label>
    </div>
  );
}

export default SearchBar;
