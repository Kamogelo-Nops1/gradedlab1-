import React, { useState } from 'react';
import SearchBar from './Search';
import ProductList from './Product';

const products = [
  
    { id: 1, name: "Blue T-Shirt", category: "Clothing", price: 150, inStock: true },
    { id: 2, name: "Black Jeans", category: "Clothing", price: 300, inStock: false },
    { id: 3, name: "Red Sneakers", category: "Shoes", price: 500, inStock: true },
    { id: 4, name: " Mouse", category: "Accessories", price: 250, inStock: true },
    { id: 5, name: "Table", category: "Furniture", price: 1200, inStock: false },
    { id: 6, name: "Blue Jersey", category: "Clothing", price: 200, inStock: true },
    { id: 7, name: "Beanie", category: "Accessories", price: 180, inStock: true },
    { id: 8, name: "slides", category: "Shoes", price: 650, inStock: false },
    { id: 9, name: "headphones", category: "Accessories", price: 900, inStock: true },
    { id: 10, name: "Chair", category: "Furniture", price: 1700, inStock: true },
  
];

function App() {
  const [searchText, setSearchText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [inStockOnly, setInStockOnly] = useState(false);

  const filteredProducts = products.filter(product => {
    const matchesName = product.name.toLowerCase().includes(searchText.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesStock = !inStockOnly || product.inStock;
    return matchesName && matchesCategory && matchesStock;
  });

  return (
    <div className="App" style={{ padding: '20px' }}>
      <h1>Product Catalog</h1>
      <SearchBar
        searchText={searchText}
        onSearchChange={setSearchText}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        inStockOnly={inStockOnly}
        onInStockChange={setInStockOnly}
      />
      <ProductList products={filteredProducts} />
    </div>
  );
}

export default App;
