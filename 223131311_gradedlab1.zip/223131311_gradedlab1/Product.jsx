import React from 'react';
import ProductItem from './Item';

function List({ products }) {
  if (products.length === 0) {
    return <p>No products found.</p>;
  }

  return (
    <ul>
      {products.map(item => (
        <ProductItem key={item.id} product={item} />
      ))}
    </ul>
  );
}

export default List;
