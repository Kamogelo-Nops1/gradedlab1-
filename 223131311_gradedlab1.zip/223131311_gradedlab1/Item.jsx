import React from 'react';

function ProductItem({ product }) {
  return (
    <li>
      <strong>{product.name}</strong> - {product.category} - R{product.price} - 
      {product.inStock ? ' In Stock' : ' Out of Stock'}
    </li>
  );
}

export default ProductItem;
